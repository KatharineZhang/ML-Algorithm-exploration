from . import ridge_regression_mnist, poly_regression

__all__ = ["ridge_regression_mnist", "poly_regression"]
